﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Manager
{
    public class PRMS
    {
        public static List<string> lista_uloga = new List<string>()
        {
            "OtvoriRacun",
            "ZatvoriRacun",
            "ProveriStanje",
            "Isplata",
            "Uplata",
            "Opomena"
        };
    }
}
