﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    [Serializable]
    [DataContract]
    public class Korisnik
    {
        [DataMember]
        private string username;

        public string Username
        {
            get { return username; }
            set { username = value; }
        }

        public Korisnik(string user)
        {
            Username = user;
        }

    }
}
