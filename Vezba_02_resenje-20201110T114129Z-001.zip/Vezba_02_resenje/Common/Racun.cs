﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    [Serializable]
    [DataContract]
    public class Racun
    {
        [DataMember]
        private long brojRacuna;

        public long BrojRacuna
        {
            get { return brojRacuna; }
            set { brojRacuna = value; }
        }
        [DataMember]

        private double iznos;

        public double Iznos
        {
            get { return iznos; }
            set { iznos = value; }
        }
        [DataMember]

        private double dozvoljeniMinus;

        public double DozvoljeniMinus
        {
            get { return dozvoljeniMinus; }
            set { dozvoljeniMinus = value; }
        }
        [DataMember]

        private double blokiran;

        public double Blokiran
        {
            get { return blokiran; }
            set { blokiran = value; }
        }
        [DataMember]

        private DateTime poslednjaTransakcija;

        public DateTime PoslednjaTransakcija
        {
            get { return poslednjaTransakcija; }
            set { poslednjaTransakcija = value; }
        }
        [DataMember]

        private Korisnik vlasnik;

        public Korisnik Vlasnik
        {
            get { return vlasnik; }
            set { vlasnik = value; }
        }

        public Racun(long broj, double iznos, double minus, double blok, DateTime posltrans, Korisnik vlasnik)
        {
            BrojRacuna = broj;
            Iznos = iznos;
            DozvoljeniMinus = minus;
            Blokiran = blokiran;
            PoslednjaTransakcija = posltrans;
            Vlasnik = vlasnik;
        }
    }
}
